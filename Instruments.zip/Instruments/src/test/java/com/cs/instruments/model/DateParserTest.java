package com.cs.instruments.model;

import java.io.IOException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class DateParserTest extends TestCase {

	@InjectMocks
	DateParser dateParser = new DateParser();

	@Test
	public void testParseableDate12May2014() throws IOException, ParseException {
		// given
		String dateString = "12-May-2014";
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.DAY_OF_MONTH, 12);
		calendar.set(Calendar.MONTH, 4);
		calendar.set(Calendar.YEAR, 2014);
		Date date = calendar.getTime();

		// when
		Date dateParsed = dateParser.parse(dateString);

		// then
		assertEquals(date.getTime(), dateParsed.getTime());
	}

	@Test
	public void testParseableDate25September2011() throws IOException, ParseException {
		// given
		String dateString = "25-Sep-2011";
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.DAY_OF_MONTH, 25);
		calendar.set(Calendar.MONTH, 8);
		calendar.set(Calendar.YEAR, 2011);
		Date date = calendar.getTime();

		// when
		Date dateParsed = dateParser.parse(dateString);

		// then
		assertEquals(date.getTime(), dateParsed.getTime());
	}

	@Test
	public void testReadWrongMonthLine28Mag2014() throws IOException, ParseException {
		// given
		String dateString = "28-Mag-2014";

		// when
		try {
			dateParser.parse(dateString);
			// then
			fail("Exception not thrown");
		} catch (Exception e) {
		}

	}

	@Test
	public void testReadWrongDayLine35Apr2014() throws IOException, ParseException {
		// given
		String dateString = "35-Apr-2014";
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.DAY_OF_MONTH, 5);
		calendar.set(Calendar.MONTH, 4);// it's May already ;)
		calendar.set(Calendar.YEAR, 2014);
		Date date = calendar.getTime();

		// when
		Date dateParsed = dateParser.parse(dateString);

		// then
		assertEquals(date.getTime(), dateParsed.getTime());
	}
}
