package com.cs.instruments.model.statistics;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.cs.instruments.model.DateParser;
import com.cs.instruments.model.instrument.Instrument;

import junit.framework.TestCase;

@RunWith(MockitoJUnitRunner.class)
public class InstrumentStatisticsOtherTest extends TestCase {

	//TODO jeszcze duæo testów
	
	@InjectMocks
	InstrumentStatisticsOther instrumentStatisticsOther;
	
	@Mock
	DateParser dateParser;
	
	@Mock
	Instrument instrument1;
	
	@Mock
	Instrument instrument2;
	
	@Mock
	Instrument instrument3;
	
    @Before 
    public void setup() {
    	instrumentStatisticsOther = new InstrumentStatisticsOther();
    	dateParser = new DateParser();
    }
    
    @Test
    public void testActualizeNewestOfTheOthersShouldSort() throws ParseException {
    	// given
		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("546.55"));
		Mockito.when(instrument2.getValue()).thenReturn(new BigDecimal("2346.78"));
		Mockito.when(instrument3.getValue()).thenReturn(new BigDecimal("78.55464"));
		Mockito.when(instrument1.getDate()).thenReturn(dateParser.parse("15-May-2001"));
		Mockito.when(instrument2.getDate()).thenReturn(dateParser.parse("04-Jan-2005"));
		Mockito.when(instrument3.getDate()).thenReturn(dateParser.parse("15-Dec-2000"));
		
		List<Instrument> instruments = new ArrayList<Instrument>();
		instruments.add(instrument1);
		instruments.add(instrument2);
		
		instrumentStatisticsOther.newestOfTheOthers = instruments;
		instrumentStatisticsOther.numberOfElements = 2;

		// when
		instrumentStatisticsOther.addInstrument(instrument3);
		
		// then
		assertEquals(Integer.valueOf(3), instrumentStatisticsOther.getNumberOfElements());
		assertEquals(Integer.valueOf(3), instrumentStatisticsOther.getNumberOfTheNewestOffTheList());
		assertEquals(dateParser.parse("15-Dec-2000"), instrumentStatisticsOther.getNewestOfTheOthers().get(0).getDate());
    }
    
    @Test
    public void testActualizeNewestOfTheOthersShouldThrowAwayOldest() throws ParseException {
    	// given
		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("5424326.55"));
		Mockito.when(instrument2.getValue()).thenReturn(new BigDecimal("2323446.2438"));
		Mockito.when(instrument3.getValue()).thenReturn(new BigDecimal("7823.55464"));
		Mockito.when(instrument1.getDate()).thenReturn(dateParser.parse("05-Aug-2001"));
		Mockito.when(instrument2.getDate()).thenReturn(dateParser.parse("04-Feb-2015"));
		Mockito.when(instrument3.getDate()).thenReturn(dateParser.parse("15-Dec-2000"));
		
		instrumentStatisticsOther.addInstrument(instrument1);
		instrumentStatisticsOther.addInstrument(instrument1);
		instrumentStatisticsOther.addInstrument(instrument1);
		instrumentStatisticsOther.addInstrument(instrument1);
		instrumentStatisticsOther.addInstrument(instrument1);
		instrumentStatisticsOther.addInstrument(instrument1);
		instrumentStatisticsOther.addInstrument(instrument3);
		instrumentStatisticsOther.addInstrument(instrument2);
		instrumentStatisticsOther.addInstrument(instrument2);
		instrumentStatisticsOther.addInstrument(instrument2);
		
		// when
		instrumentStatisticsOther.addInstrument(instrument2);
		
		// then
		assertEquals(Integer.valueOf(11), instrumentStatisticsOther.getNumberOfElements());
		assertEquals(Integer.valueOf(10), instrumentStatisticsOther.getNumberOfTheNewestOffTheList());
		assertEquals(dateParser.parse("05-Aug-2001"), instrumentStatisticsOther.getNewestOfTheOthers().get(0).getDate());
    }

	@Test
	public void testSumOfTheNewestOffTheList0Elements() {
		// given
		// when

		// then
		assertEquals(BigDecimal.ZERO, instrumentStatisticsOther.getSumOfTheNewestOffTheList());
	}
	
	@Test
	public void testSumOfTheNewestOffTheList1Element() throws ParseException {
		// given
		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("546.55"));
		Mockito.when(instrument1.getDate()).thenReturn(dateParser.parse("15-May-2001"));
		
		// when
		instrumentStatisticsOther.addInstrument(instrument1);
		
		// then
		assertEquals(new BigDecimal("546.55"), instrumentStatisticsOther.getSumOfTheNewestOffTheList());
	}
	
	
//	
//	@Test
//	public void testMinimum1Intrument3Times() throws ParseException {
//		// given
//		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("546.55"));
//
//		// when
//		instrumentStatisticsExtended.addInstrument(instrument1);
//		instrumentStatisticsExtended.addInstrument(instrument1);
//		instrumentStatisticsExtended.addInstrument(instrument1);
//
//		// then
//		assertEquals(new BigDecimal("546.55"), instrumentStatisticsExtended.getMaximum());
//	}
//	
//	@Test
//	public void testMinimumEmptySet() ParseException {
//		// given
//
//		// when
//
//		// then
//		assertNull(instrumentStatisticsExtended.getMinimum());
//	}
//	
//	@Test
//	public void testMaximum1Intrument3Times() throws ParseException {
//		// given
//		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("-4354.56"));
//
//		// when
//		instrumentStatisticsExtended.addInstrument(instrument1);
//		instrumentStatisticsExtended.addInstrument(instrument1);
//		instrumentStatisticsExtended.addInstrument(instrument1);
//
//		// then
//		assertEquals(new BigDecimal("-4354.56"), instrumentStatisticsExtended.getMaximum());
//	}
//	
//	@Test
//	public void testMaximum3Intruments() throws ParseException {
//		// given
//		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("1323.75"));
//		Mockito.when(instrument2.getValue()).thenReturn(new BigDecimal("-4445.313"));
//		Mockito.when(instrument3.getValue()).thenReturn(new BigDecimal("56234.83342"));
//
//		// when
//		instrumentStatisticsExtended.addInstrument(instrument1);
//		instrumentStatisticsExtended.addInstrument(instrument2);
//		instrumentStatisticsExtended.addInstrument(instrument3);
//
//		// then
//		assertEquals(new BigDecimal("56234.83342"), instrumentStatisticsExtended.getMaximum());
//	}
//	
//	@Test
//	public void testMaximumEmptySet() throws ParseException {
//		// given
//
//		// when
//
//		// then
//		assertNull(instrumentStatisticsExtended.getMaximum());
//	}
//	
}
