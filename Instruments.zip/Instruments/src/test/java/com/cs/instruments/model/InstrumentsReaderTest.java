package com.cs.instruments.model;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.cs.instruments.model.instrument.Instrument;

@RunWith(MockitoJUnitRunner.class)
public class InstrumentsReaderTest extends TestCase {

	@Mock BufferedReader bufferedReader;
	@Mock DateParser dateParser;
	@InjectMocks InstrumentsReader reader;
	
	@Test
	public void testReadParseableLine() throws IOException, ParseException {
		//given
		Mockito.when(bufferedReader.readLine()).thenReturn("INSTRUMENT1,12-May-2014,3.037");
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.DAY_OF_MONTH, 12);
		calendar.set(Calendar.MONTH, 4);
		calendar.set(Calendar.YEAR, 2014);
		Date date = calendar.getTime();
		Mockito.when(dateParser.parse(Mockito.anyString())).thenReturn(date);
		
		//when
		Instrument instrument = reader.read();
		
		//then
		assertNotNull(instrument);
		assertEquals("INSTRUMENT1", instrument.getName());
		assertEquals(date.getTime(), instrument.getDate().getTime());
		assertEquals(new BigDecimal("3.037"), instrument.getValue());
	}
	
	@Test
	public void testReadParseableLineManyDigits() throws IOException, ParseException {
		//given
		Mockito.when(bufferedReader.readLine()).thenReturn("INSTRUMENT1,24-Feb-2013,9.013633369");
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.DAY_OF_MONTH, 12);
		calendar.set(Calendar.MONTH, 8);
		calendar.set(Calendar.YEAR, 1998);
		Date date = calendar.getTime();
		Mockito.when(dateParser.parse(Mockito.anyString())).thenReturn(date);
		
		//when
		Instrument instrument = reader.read();
		
		//then
		assertNotNull(instrument);
		assertEquals("INSTRUMENT1", instrument.getName());
		assertEquals(date.getTime(), instrument.getDate().getTime());
		assertEquals(new BigDecimal("9.013633369"), instrument.getValue());
	}

	@Test
	public void testReadWrongDateLine() throws IOException, ParseException {
		//given
		Mockito.when(bufferedReader.readLine()).thenReturn("INSTRUMENT1,12-Mag-2014,3.037");
		Mockito.when(dateParser.parse(Mockito.anyString())).thenThrow(new ParseException("Exception", 5));
				
		//when
		try{
			reader.read();
			//then
			fail("Exception not thrown");
		}catch(Exception e){
		}

	}
}
