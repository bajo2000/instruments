package com.cs.instruments.model.statistics;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.cs.instruments.model.instrument.Instrument;

@RunWith(MockitoJUnitRunner.class)
public class InstrumentStatisticsExtendedTest extends TestCase {

	@Mock Instrument instrument;

	@InjectMocks
	InstrumentStatistics instrumentStatistics;
	
	@Test
	public void testSum() throws IOException, ParseException {
		// given
		Mockito.when(instrument.getValue()).thenReturn(
				new BigDecimal("123.33"), new BigDecimal("45.31235"), new BigDecimal("56.879342"));

		// when
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);

		// then
		assertEquals(new BigDecimal("225.521692"), instrumentStatistics.getSum());
	}
	
	@Test
	public void testMean() throws IOException, ParseException {
		// given
		Mockito.when(instrument.getValue()).thenReturn(
				new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0"));

		// when
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);

		// then
		assertEquals(new BigDecimal("2.0").setScale(8, BigDecimal.ROUND_HALF_UP), instrumentStatistics.getMean());
	}
	
	@Test
	public void testSum1Element() throws IOException, ParseException {
		// given
		Mockito.when(instrument.getValue()).thenReturn(new BigDecimal("5.54686"));

		// when
		instrumentStatistics.addInstrument(instrument);

		// then
		assertEquals(new BigDecimal("5.54686").setScale(8, BigDecimal.ROUND_HALF_UP), instrumentStatistics.getMean());
	}
	
	@Test
	public void testMean1Element() throws IOException, ParseException {
		// given
		Mockito.when(instrument.getValue()).thenReturn(new BigDecimal("7.34355"));

		// when
		instrumentStatistics.addInstrument(instrument);

		// then
		assertEquals(new BigDecimal("7.34355").setScale(8, BigDecimal.ROUND_HALF_UP), instrumentStatistics.getMean());
	}
	
	@Test
	public void testSumNegatives() throws IOException, ParseException {
		// given
		Mockito.when(instrument.getValue()).thenReturn(
				new BigDecimal("-13523.33"), new BigDecimal("45.315"), new BigDecimal("-5556.8342"));

		// when
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);

		// then
		assertEquals(new BigDecimal("-19034.8492"), instrumentStatistics.getSum());
	}
	
	@Test
	public void testMeanNegatives() throws IOException, ParseException {
		// given
		Mockito.when(instrument.getValue()).thenReturn(
				new BigDecimal("2.33"), new BigDecimal("-1.66"), new BigDecimal("5.33"));

		// when
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);

		// then
		assertEquals(new BigDecimal("2.0").setScale(8, BigDecimal.ROUND_HALF_UP), instrumentStatistics.getMean());
	}
	
	@Test
	public void testMeanOfNoElements() throws IOException, ParseException {
		// given

		// when
		
		//when
		try{
			instrumentStatistics.getMean();
			//then
			fail("Exception not thrown - no mean of the empty set");
		}catch(Exception e){
		}
	}
	
	@Test
	public void testNumberOfElements5Elements() throws IOException, ParseException {
		// given
		Mockito.when(instrument.getValue()).thenReturn(new BigDecimal("3434.3234233"));

		// when
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);
		instrumentStatistics.addInstrument(instrument);
		
		// then
		assertEquals(Integer.valueOf(5), instrumentStatistics.getNumberOfElements());
	}
	
}
