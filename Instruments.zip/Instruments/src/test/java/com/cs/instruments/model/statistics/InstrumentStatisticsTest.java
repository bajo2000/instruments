package com.cs.instruments.model.statistics;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.cs.instruments.model.instrument.Instrument;

@RunWith(MockitoJUnitRunner.class)
public class InstrumentStatisticsTest extends TestCase {

	@InjectMocks
	InstrumentStatisticsExtended instrumentStatisticsExtended;
	
	@Mock
	Instrument instrument1;
	
	@Mock
	Instrument instrument2;
	
	@Mock
	Instrument instrument3;
	
	@Test
	public void testMinimum3Intruments() throws IOException, ParseException {
		// given
		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("123.33"));
		Mockito.when(instrument2.getValue()).thenReturn(new BigDecimal("45.31235"));
		Mockito.when(instrument3.getValue()).thenReturn(new BigDecimal("56.879342"));

		// when
		instrumentStatisticsExtended.addInstrument(instrument1);
		instrumentStatisticsExtended.addInstrument(instrument2);
		instrumentStatisticsExtended.addInstrument(instrument3);

		// then
		assertEquals(new BigDecimal("45.31235"), instrumentStatisticsExtended.getMinimum());
	}
	
	@Test
	public void testMinimum1Intrument3Times() throws IOException, ParseException {
		// given
		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("546.55"));

		// when
		instrumentStatisticsExtended.addInstrument(instrument1);
		instrumentStatisticsExtended.addInstrument(instrument1);
		instrumentStatisticsExtended.addInstrument(instrument1);

		// then
		assertEquals(new BigDecimal("546.55"), instrumentStatisticsExtended.getMaximum());
	}
	
	@Test
	public void testMinimumEmptySet() throws IOException, ParseException {
		// given

		// when

		// then
		assertNull(instrumentStatisticsExtended.getMinimum());
	}
	
	@Test
	public void testMaximum1Intrument3Times() throws IOException, ParseException {
		// given
		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("-4354.56"));

		// when
		instrumentStatisticsExtended.addInstrument(instrument1);
		instrumentStatisticsExtended.addInstrument(instrument1);
		instrumentStatisticsExtended.addInstrument(instrument1);

		// then
		assertEquals(new BigDecimal("-4354.56"), instrumentStatisticsExtended.getMaximum());
	}
	
	@Test
	public void testMaximum3Intruments() throws IOException, ParseException {
		// given
		Mockito.when(instrument1.getValue()).thenReturn(new BigDecimal("1323.75"));
		Mockito.when(instrument2.getValue()).thenReturn(new BigDecimal("-4445.313"));
		Mockito.when(instrument3.getValue()).thenReturn(new BigDecimal("56234.83342"));

		// when
		instrumentStatisticsExtended.addInstrument(instrument1);
		instrumentStatisticsExtended.addInstrument(instrument2);
		instrumentStatisticsExtended.addInstrument(instrument3);

		// then
		assertEquals(new BigDecimal("56234.83342"), instrumentStatisticsExtended.getMaximum());
	}
	
	@Test
	public void testMaximumEmptySet() throws IOException, ParseException {
		// given

		// when

		// then
		assertNull(instrumentStatisticsExtended.getMaximum());
	}
	
}
