package com.cs.instruments.model.instrument;

import java.math.BigDecimal;
import java.util.Date;

public class InstrumentMultiplierDecorator extends Instrument {
	
	private Instrument instrument;
	private BigDecimal multiplier;
	
	public InstrumentMultiplierDecorator () {
		super();
	}
	
    public InstrumentMultiplierDecorator (Instrument instrument) {
        this.instrument = instrument;
    }
    
	@Override
	public BigDecimal getValue() {
		BigDecimal value = instrument.getValue();
		if (multiplier != null) {
			value = value.multiply(multiplier);
		}
		return value;
	}

	@Override
	public String getName() {
		return instrument.getName();
	}

	@Override
	public Date getDate() {
		return instrument.getDate();
	}
	
	public static class Builder {		
		private Instrument instrument;
		private BigDecimal multiplier;

		public Builder instrument(Instrument instrument) {
			this.instrument = instrument;
			return this;
		}
		
		public Builder multiplier(BigDecimal multiplier) {
			this.multiplier = multiplier;
			return this;
		}

		public InstrumentMultiplierDecorator build() {
			return new InstrumentMultiplierDecorator(this);
		}
	}

	private InstrumentMultiplierDecorator(Builder builder) {
		instrument = builder.instrument;
		multiplier = builder.multiplier;
	}
}
