package com.cs.instruments.model.instrument;

import java.math.BigDecimal;
import java.util.Date;

public class Instrument {
	String name;
	Date date;
	BigDecimal value;
	
	public Instrument() {
		super();
	}
	
	public String getName() {
		return name;
	}
	public Date getDate() {
		return date;
	}
	public BigDecimal getValue() {
		return value;
	}
	
	
	public static class Builder {		
		private String name;
		private Date date;
		private BigDecimal value;

		public Builder name(String name) {
			this.name = name;
			return this;
		}

		public Builder date(Date date) {
			this.date = date;
			return this;
		}

		public Builder value(BigDecimal value) {
			this.value = value;
			return this;
		}

		public Instrument build() {
			return new Instrument(this);
		}
	}

	private Instrument(Builder builder) {
		name = builder.name;
		date = builder.date;
		value = builder.value;
		
		//TODO validation
	}
}
