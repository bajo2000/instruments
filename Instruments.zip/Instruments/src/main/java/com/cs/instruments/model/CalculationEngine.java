package com.cs.instruments.model;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cs.instruments.model.instrument.Instrument;
import com.cs.instruments.model.instrument.InstrumentFactory;
import com.cs.instruments.model.statistics.InstrumentStatistics;
import com.cs.instruments.model.statistics.InstrumentStatisticsExtended;
import com.cs.instruments.model.statistics.InstrumentStatisticsOther;

@Component
public class CalculationEngine {
	@Autowired
	InstrumentFactory instrumentFactory;
	
	private InstrumentStatistics instruments1Statistics = new InstrumentStatistics();
	private InstrumentStatistics instruments2November2014Statistics = new InstrumentStatistics();
	private InstrumentStatisticsExtended instrument3Statistics = new InstrumentStatisticsExtended();
	private InstrumentStatisticsOther otherInstrumentStatistics = new InstrumentStatisticsOther();

	public void addInstrument(Instrument instrument) {
		Instrument finalInstrument = instrumentFactory.getInstrument(instrument);
		
		//I'm trying to avoid switches, but it has to be somewhere
		switch (finalInstrument.getName()) {
		case "INSTRUMENT1":
			instruments1Statistics.addInstrument(finalInstrument);
			break;
		case "INSTRUMENT2":
			instruments2November2014Statistics.addInstrument(finalInstrument);
			break;
		case "INSTRUMENT3":
			instrument3Statistics.addInstrument(finalInstrument);
			break;
		default:
			otherInstrumentStatistics.addInstrument(finalInstrument);
			break;
		}
	}
	
	public BigDecimal instruments1Mean() {
		return instruments1Statistics.getMean();
	}
	
	public BigDecimal instruments2November2014Mean() {
		return instruments2November2014Statistics.getMean();
	}
	
	public InstrumentStatistics instruments3Statistics() {
		return instrument3Statistics;
	}
	
	public BigDecimal getSumOfTheNewestOffTheList() {
		return otherInstrumentStatistics.getSumOfTheNewestOffTheList();
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("INSTRUMENT1 statistics: \n");
		buffer.append(instruments1Statistics.toString());
		buffer.append("\n");
		buffer.append("INSTRUMENT2 November2014 statistics: \n");
		buffer.append(instruments2November2014Statistics.toString());
		buffer.append("\n");
		buffer.append("INSTRUMENT3 statistics: \n");
		buffer.append(instrument3Statistics.toString());
		buffer.append("\n");
		buffer.append("OTHER INSTRUMENTS statistics: \n");
		buffer.append(otherInstrumentStatistics.toString());
		buffer.append("\n");

		return buffer.toString();
	}
}
