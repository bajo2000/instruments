package com.cs.instruments.dao;

public class InstrumentsDao {

}
