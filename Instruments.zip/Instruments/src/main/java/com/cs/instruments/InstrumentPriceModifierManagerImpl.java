package com.cs.instruments;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cs.instruments.dao.InstrumentPriceModifierDao;
import com.cs.instruments.model.instrument.InstrumentPriceModifier;

@Service
public class InstrumentPriceModifierManagerImpl implements InstrumentPriceModifierManager {

	@Autowired
	private InstrumentPriceModifierDao instrumentPriceModifierDao;

	@Override
	public InstrumentPriceModifier findInstrumentPriceModifierByName(String name) {
		return instrumentPriceModifierDao.findByName(name);
	}
}
