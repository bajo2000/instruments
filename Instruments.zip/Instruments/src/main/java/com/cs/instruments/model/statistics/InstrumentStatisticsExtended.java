package com.cs.instruments.model.statistics;

import java.math.BigDecimal;

import com.cs.instruments.model.instrument.Instrument;

public class InstrumentStatisticsExtended extends InstrumentStatistics {
	BigDecimal minimum;
	BigDecimal maximum;

	@Override
	public void addInstrument(Instrument instrument) {
		super.addInstrument(instrument);

		BigDecimal newValue = instrument.getValue();
		if (minimum != null) {
			minimum = newValue.min(minimum);
			maximum = newValue.max(maximum);
		} else {
			minimum = newValue;
			maximum = newValue;
		}
	}

	public BigDecimal getMinimum() {
		return minimum;
	}

	public BigDecimal getMaximum() {
		return maximum;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(super.toString());
		buffer.append("Minimum of elements: ");
		buffer.append(minimum);
		buffer.append("\n");
		buffer.append("Maksimum of elements: ");
		buffer.append(maximum);
		buffer.append("\n");
		return buffer.toString();
	}
}

