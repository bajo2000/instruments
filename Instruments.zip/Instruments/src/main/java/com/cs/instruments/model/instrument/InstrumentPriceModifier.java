package com.cs.instruments.model.instrument;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INSTRUMENT_PRICE_MODIFIER")
public class InstrumentPriceModifier {
	
	@Id
	@Column(name = "id")
	private Integer id;
	@Column(name = "name")
	private String name;
	@Column(name = "multiplier")
	private BigDecimal multiplier;
	
	public Integer getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public BigDecimal getMultiplier() {
		return multiplier;
	}
	
	
}