package com.cs.instruments.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cs.instruments.model.instrument.InstrumentPriceModifier;

@Repository
public class InstrumentPriceModifierDaoImpl implements InstrumentPriceModifierDao {
	
	@PersistenceContext(unitName="InstrumentsPersistance")
	private EntityManager entityManager;
	
	@Transactional
	public InstrumentPriceModifier findByName(String name) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<InstrumentPriceModifier> query = cb.createQuery(InstrumentPriceModifier.class);

		Root<InstrumentPriceModifier> instrumentPriceModifier = query.from(InstrumentPriceModifier.class);
		Predicate instrumentPriceModifierEqual = cb.equal(instrumentPriceModifier.get("name"), name);
		query.where(instrumentPriceModifierEqual);
	
		List<InstrumentPriceModifier> resultList = entityManager.createQuery(query).getResultList();
		if (resultList.size() > 0) {
			return resultList.get(0);
		} else return null;
	}
}