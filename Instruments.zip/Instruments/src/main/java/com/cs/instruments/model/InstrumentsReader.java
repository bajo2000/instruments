package com.cs.instruments.model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cs.instruments.model.instrument.Instrument;

@Component
public class InstrumentsReader {
	@Value("${instruments.filename}")
	String filename;
	
    FileReader inputFile;
    BufferedReader bufferReader;
    
    @Autowired
    DateParser dateParser;

	public InstrumentsReader() {
		super();
	}

	public InstrumentsReader(String filename) {
		super();
		this.filename = filename;
	}
	
	public Instrument read() throws IOException, ParseException {
		String line = bufferReader.readLine();
		Instrument instrument = null;
		
	    if (line != null) {
	    	String[] fields = line.split("[,]");
	    	String name = fields[0];
	    	Date date = dateParser.parse(fields[1]);
	    	BigDecimal value = new BigDecimal(fields[2]);
	    	instrument = new Instrument.Builder().name(name).date(date).value(value).build();
	    }
	    
		return instrument;
	}
	
	public void openFile() throws FileNotFoundException {
		//Create object of FileReader
	    inputFile = new FileReader(filename);

	    //Instantiate the BufferedReader Class
	    bufferReader = new BufferedReader(inputFile);
	}
	
	public void closeFile() throws IOException {
		bufferReader.close();
		inputFile.close();
	}
	
	public void setDateParser(DateParser dateParser) {
		this.dateParser = dateParser;
	}
	
}
