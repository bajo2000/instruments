package com.cs.instruments.dao;

import com.cs.instruments.model.instrument.InstrumentPriceModifier;
import com.google.common.base.Optional;

public interface InstrumentPriceModifierDao {
	abstract Optional<InstrumentPriceModifier> findByName(String name);
}