package com.cs.instruments.dao;

import com.cs.instruments.model.instrument.InstrumentPriceModifier;

public interface InstrumentPriceModifierDao {
	abstract InstrumentPriceModifier findByName(String name);
}