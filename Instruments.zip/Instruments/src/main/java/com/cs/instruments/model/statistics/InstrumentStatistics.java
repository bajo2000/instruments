package com.cs.instruments.model.statistics;

import java.math.BigDecimal;

import com.cs.instruments.model.instrument.Instrument;

public class InstrumentStatistics {

	BigDecimal sum = BigDecimal.ZERO;
	Integer numberOfElements = Integer.valueOf(0);
	
	public void addInstrument(Instrument instrument) {
		sum = instrument.getValue().add(sum);
		numberOfElements++;
	}

	public BigDecimal getSum() {
		return sum;
	}

	public Integer getNumberOfElements() {
		return numberOfElements;
	}
	
	public BigDecimal getMean() {
		return sum.divide(new BigDecimal(numberOfElements), 8, BigDecimal.ROUND_HALF_UP);
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("Number of elements: ");
		buffer.append(numberOfElements);
		buffer.append("\n");
		buffer.append("Sum of elements: ");
		buffer.append(sum);
		buffer.append("\n");
		buffer.append("Mean of elements: ");
		buffer.append(getMean());
		buffer.append("\n");
		return buffer.toString();
	}
}
