package com.cs.instruments.model.instrument;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cs.instruments.InstrumentPriceModifierManager;

@Component
public class InstrumentFactory {
	
	@Autowired
	InstrumentPriceModifierManager instrumentPriceModifierManager;
	
	public Instrument getInstrument(Instrument instrument) {
		InstrumentPriceModifier instrumentPriceModifier = 
				instrumentPriceModifierManager.findInstrumentPriceModifierByName(instrument.getName());
		
		if(instrumentPriceModifier !=null && instrumentPriceModifier.getMultiplier() != null) {
			return new InstrumentMultiplierDecorator.Builder().
					instrument(instrument).multiplier(instrumentPriceModifier.getMultiplier()).
					build();
		} else {
			return instrument;
		}
	}
}
