package com.cs.instruments.model.instrument;

import java.math.BigDecimal;

public class InstrumentStatisticsExtended extends InstrumentStatistics {
	BigDecimal minimum = BigDecimal.ZERO;
	BigDecimal maximum = BigDecimal.ZERO;
	
	@Override
	public void addInstrument(Instrument instrument) {
		super.addInstrument(instrument);
		minimum = instrument.getValue().min(minimum);
		maximum = instrument.getValue().min(maximum);
	}
	
	public BigDecimal getMinimum() {
		return minimum;
	}
	
	public BigDecimal getMaximum() {
		return maximum;
	}
	
}
