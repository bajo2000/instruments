package com.cs.instruments.model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.stereotype.Component;

@Component
public class DateParser {
    DateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);

	public DateParser() {
		super();
	}

	public Date parse(String date) throws ParseException {
		return df.parse(date);
	}
}
