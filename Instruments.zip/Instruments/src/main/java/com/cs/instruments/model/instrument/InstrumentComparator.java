package com.cs.instruments.model.instrument;

import java.util.Comparator;

public class InstrumentComparator implements Comparator<Instrument> {

	@Override
	public int compare(Instrument arg0, Instrument arg1) {
		return arg0.getDate().compareTo(arg1.getDate());
	}
	
}
