package com.cs.instruments.model.statistics;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.cs.instruments.model.instrument.Instrument;
import com.cs.instruments.model.instrument.InstrumentComparator;

public class InstrumentStatisticsOther extends InstrumentStatistics {
	
	List<Instrument> newestOfTheOthers = new ArrayList<Instrument>();
	
	public void addInstrument(Instrument instrument) {
		super.addInstrument(instrument);
		actualizeNewestOfTheOthers(instrument);
	}

	void actualizeNewestOfTheOthers(Instrument instrument) {
		newestOfTheOthers.add(instrument);
		Collections.sort(newestOfTheOthers, new InstrumentComparator());
		
		//remove the oldest instrument if there is too much
		if (newestOfTheOthers.size() > numberOfTheNewestOffTheListParameter()) {
			newestOfTheOthers.remove(0);
		}
	}

	public BigDecimal getSumOfTheNewestOffTheList() {
		BigDecimal sumOfTheNewestOffTheList = BigDecimal.ZERO;
		for (Instrument instrument: newestOfTheOthers) {
			sumOfTheNewestOffTheList = sumOfTheNewestOffTheList.add(instrument.getValue());
		}
		return sumOfTheNewestOffTheList;
	}
	
	public Integer getNumberOfTheNewestOffTheList() {
		return newestOfTheOthers.size();
	}
	
	public List<Instrument> getNewestOfTheOthers() {
		return newestOfTheOthers;
	}

	//TODO jakaś adnotacja spring z propertiesow
	private Integer numberOfTheNewestOffTheListParameter() {
		return 10;
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(super.toString());
		buffer.append("Sum of 10 newest elements: ");
		buffer.append(getSumOfTheNewestOffTheList());
		buffer.append("\n");
		return buffer.toString();
	}
}
