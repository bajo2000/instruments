package com.cs.instruments.dao;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import com.cs.instruments.model.instrument.InstrumentPriceModifier;


public class InstrumentPriceModifierDaoProxy implements InstrumentPriceModifierDao {
	
	@Override
	public InstrumentPriceModifier findByName(String name) {
		Cache cache = CacheManager.getInstance().getCache("cacheInstrumentsModifiers");
		Element modifier = cache.get(name);
		InstrumentPriceModifier instrumentPriceModifier = (InstrumentPriceModifier) modifier.getObjectValue();
		
		
		return null;
	}
}