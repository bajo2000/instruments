package com.cs.instruments.model.instrument;

import java.math.BigDecimal;

public class InstrumentStatistics {

	BigDecimal sum = BigDecimal.ZERO;
	Integer numberOfElements = Integer.valueOf(0);
	
	public void addInstrument(Instrument instrument) {
		sum = instrument.getValue().add(sum);
		numberOfElements++;
	}

	public BigDecimal getSum() {
		return sum;
	}

	public Integer getNumberOfElements() {
		return numberOfElements;
	}
	
	public BigDecimal getMean() {
		return sum.divide(new BigDecimal(numberOfElements), 8, BigDecimal.ROUND_HALF_UP);
	}
}
