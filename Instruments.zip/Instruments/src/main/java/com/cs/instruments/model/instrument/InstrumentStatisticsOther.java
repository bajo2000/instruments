package com.cs.instruments.model.instrument;

import java.math.BigDecimal;
import java.util.Date;

public class InstrumentStatisticsOther {
	
	private BigDecimal sumOfTheNewestOffTheList = BigDecimal.ZERO;
	private Integer numberOfTheNewestOffTheList = Integer.valueOf(0);
	private Date oldestOfTheNewestOffTheList = new Date();
	
	public void addInstrument(Instrument instrument) {
		//TODO aktualizacja statystyk w locie
	}

	public BigDecimal getSumOfTheNewestOffTheList() {
		return sumOfTheNewestOffTheList;
	}

	//TODO jakaś adnotacja spring z propertiesow
	Integer numberOfTheNewestOffTheListParameter() {
		return 10;
	}
}
