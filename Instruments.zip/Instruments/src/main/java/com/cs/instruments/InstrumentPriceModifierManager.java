package com.cs.instruments;

import com.cs.instruments.model.instrument.InstrumentPriceModifier;

public interface InstrumentPriceModifierManager {

	InstrumentPriceModifier findInstrumentPriceModifierByName(String name);
}
